<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fruits</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <section class="fruits" id="fruits">
        <?php
        include "config.php";
        if($_GET['id']){
            $product_id=$_GET['id'];
        }
        $sql1="SELECT * FROM `product` LEFT JOIN `category` ON `product`.`category_id`= `category`.`category_id` WHERE `category`. `category_id`='{$product_id}'";
	    $query1=mysqli_query($con,$sql1);
        $result1=mysqli_fetch_assoc($query1);
        ?>

        <h1 class="heading"> Fresh<span><?= $result1['category_name']?> </span> </h1>
    
        <div class="box-container">

        <?php
	    
        if($_GET['id']){
            $product_id=$_GET['id'];
        }
       
	    $sql="SELECT * FROM `product` WHERE `product`.`category_id`='{$product_id}'";
	    $query=mysqli_query($con,$sql);
	    if($query){
		while($result=mysqli_fetch_assoc($query)){

            ?>
            <div class="box">
                <?php $img =$result['product_image'] ?>
                <img src="/Grocery/admin_panel/<?=$img?>">
                <h3><?= $result['product_name'] ?></h3>
                <p><?= $result['discount'] ?></p>
                <div class="price"><h3><?= $result['price'] ?> RS</h3></div>
                <button class="btn" data-name="<?= $result['product_name'] ?>" data-price="<?= $result['price'] ?>" data-image="/Grocery/admin_panel/<?=$img?>">Add to Cart</button>
                
            </div>
            <?php
        }}
      ?>
            
            
           

           
        </div>
    </section>

    <script>
        const addToCartButtons = document.querySelectorAll('.btn');

        addToCartButtons.forEach(button => {
            button.addEventListener('click', function () {
                const name = button.getAttribute('data-name');
                const price = parseFloat(button.getAttribute('data-price'));
                const image = button.getAttribute('data-image');
                const cartItem = { name, price, image };

                // Retrieve the existing cart or create an empty one
                const cart = JSON.parse(localStorage.getItem('cart')) || [];
                cart.push(cartItem);

                // Store the updated cart in local storage
                localStorage.setItem('cart', JSON.stringify(cart));

                // Provide feedback to the user (you can customize this)
                alert(`Product "${name}" added to the cart.`);

                // Reload the page to show the updated cart count (or redirect to the cart page)
                location.reload();
            });
        });
    </script>
</body>
</html>