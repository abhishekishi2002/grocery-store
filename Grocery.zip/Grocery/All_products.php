<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <section class="meat" id="meat">

        <h1 class="heading"> Our Fresh<span>Products</span> </h1>
    
        <div class="box-container">
<?php
include"config.php";
        $sql="SELECT * FROM `product`";
	    $query=mysqli_query($con,$sql);
	    if($query){
		while($result=mysqli_fetch_assoc($query)){
        
        ?>
        <div class="box">
        <?php $img =$result['product_image'] ?>
                <img src="/Grocery/admin_panel/<?=$img?>">
                <h1><?= $result['product_name'] ?></h1>
                <p><?= $result['discount'] ?></p>
                <div class="price"><h3><?= $result['price'] ?> RS</h3></div>
                <button class="btn" data-name="<?= $result['product_name'] ?>" data-price="<?= $result['price'] ?>" data-image="/Grocery/admin_panel/<?=$img?>">Add to Cart</button>
                <a href="cart.php" class="btn1">Buy now</a>
            </div>
        <?php
        }}
            ?>

            
        </div>
    </section>

    <script>
        const addToCartButtons = document.querySelectorAll('.btn');

        addToCartButtons.forEach(button => {
            button.addEventListener('click', function () {
                const name = button.getAttribute('data-name');
                const price = parseFloat(button.getAttribute('data-price'));
                const image = button.getAttribute('data-image');
                const cartItem = { name, price, image };

                // Retrieve the existing cart or create an empty one
                const cart = JSON.parse(localStorage.getItem('cart')) || [];
                cart.push(cartItem);

                // Store the updated cart in local storage
                localStorage.setItem('cart', JSON.stringify(cart));

                // Provide feedback to the user (you can customize this)
                alert(`Product "${name}" added to the cart.`);

                // Reload the page to show the updated cart count (or redirect to the cart page)
                location.reload();
            });
        });
    </script>
</body>
</html>