


<?php 
include 'config.php';
session_start();
error_reporting(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login page</title>
</head>
<link rel="stylesheet" href="bootstrap.min.css" />
<style>
    body{
        background-image: url('a.jpg');
        background-size:cover;
    }
    .col-xl-5{
        background:rgba(0,0,0,0.5);
        border-radius:15px 0px;
    }
    p{
        background:rgba(255, 255, 255, 0.845);
    }
    .row{
margin-top:150px;
    }
</style>

    <body>
        
            <div class="container">
                <div class="row">
                    <div class="col-xl-5 col-md-4 m-auto p-4 ">
                        <h3 class="heading text-center">Forgot Password</h3>
                        <!-- Form Start -->
                        <form  action="" method ="POST">
                            
                                <input type="text" name="email" class="form-control mb-3" placeholder="Enter Your Email" required>
                                <input type="password" name="current_password" class="form-control mb-3 " placeholder="Enter Your current Password" required>
                                <input type="password" name="password" class="form-control mb-3 " placeholder="Enter Your New Password" required>
                                <input type="submit" name="submit" class="btn btn-primary " value="Submit" />
                                <a href="login.php" class="btn btn-dark ml-2">Back</a>
                                <div>
                                    <?php
                                     
                                     if(isset($_SESSION['error'])){
                                        $error=$_SESSION['error'];
                                        echo "<p class='text-danger font-weight-bold text-center p-1'>".$error."</p>";
                                        unset($_SESSION['error']);
                                     }
                                    ?>
                        </form>
                       
                        <!-- /Form  End -->
                    </div>
                </div>
            </div>
        
    </body>

</html>

<?php
if(isset($_POST['submit'])){
    $email=$_POST['email'];
    $password=$_POST['password'];
    $current_password=$_POST['current_password'];
   
    $query=mysqli_query($con, "UPDATE `login2` SET `password`='$password' WHERE `email`='{$email}' AND `password`='{$current_password}'");
    $data=mysqli_num_rows($query);
    if($data){
      header("location:index.php");
    }

    else{
        $_SESSION['error']="Invalid email/password";
        header("location:forgot_pass.php");
    }



}



?>