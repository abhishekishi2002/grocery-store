<?php 

session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    
<section class="payment" id="payment">

	<h1 class="heading"> Pay Your<span>Bill's</span> </h1>

	<div class="box-container">
		<div class="box">
			    <label for="card_number">Card Number:</label>
                <input type="text" id="card_number" name="card_number" placeholder="1234 5678 9012 3456" required>

                <label for="cardholder_name">Cardholder Name:</label>
                <input type="text" id="cardholder_name" name="cardholder_name" placeholder="John Doe" required>

                <label for="expiry_date">Expiry Date:</label>
                <input type="text" id="expiry_date" name="expiry_date" placeholder="MM/YY" required>

                <label for="cvv">CVV:</label>
                <input type="text" id="cvv" name="cvv" placeholder="123" required>

                <a href="thanks.html" class="btn">Pay Bill</a>
                <!-- <input type="submit" name="submit" class="btn btn-primary mb-3" value="Pay Now" /> -->
		</div>
    </div>
</section>
</body>
</html>


<?php
include 'config.php';
if(isset($_POST['submit']))
{
 $card_number= $_POST['card_number'];
 $cardholder_name= $_POST['cardholder_name'];
 $expiry_date= $_POST['expiry_date'];
 $cvv= $_POST['cvv'];
 
 $sql = "INSERT INTO 'payment'(`card_number`, `cardholder_name`, `expiry_date`, `cvv`) VALUES ('$card_number','$cardholder_name','$expiry_date','$cvv')";

 $query=mysqli_query($con,$sql);

   if($query){
    header("location:thanks.html");
    
   }
//    else{
//     echo"Faild , not inserted its already used";
//    }

else{
    $_SESSION['error']="card details not valid";
    header("location:payment.php");
}

}



?>

