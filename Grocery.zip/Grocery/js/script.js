let searchForm = document.querySelector('.search-form');

document.querySelector('#search-btn').onclick = () =>
{
    searchForm.classList.toggle('active');
}

let shoppingCart = document.querySelector('.shopping-cart');

document.querySelector('#cart-btn').onclick = () =>
{
    shoppingCart.classList.toggle('active');
}

let loginForm = document.querySelector('.login-form');

document.querySelector('#login-btn').onclick = () =>
{
    loginForm.classList.toggle('active');
}



var swiper = new Swiper(".products-slider", {
    loop:true,
    spaceBetween: 20,

    autoplay: {
        delay: 7500,
        disableOnInteraction: false,
    },

    breakpoints: {
      0: {
        slidesPerView: 1,
    
      },
      768: {
        slidesPerView: 2,

      },
      1020: {
        slidesPerView: 3,
        
      },
    },
  });

  



// search bar//
// Get the input element and list
const searchInput = document.getElementById('searchInput');
const itemList = document.getElementById('itemList');
const items = itemList.getElementsByTagName('li');

// Add an event listener to the input element
searchInput.addEventListener('input', filterItems);

// Function to filter items based on user input
function filterItems() {
    const searchTerm = searchInput.value.toLowerCase();

    for (let i = 0; i < items.length; i++) {
        const item = items[i];
        const itemName = item.textContent.toLowerCase();

        if (itemName.includes(searchTerm)) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    }
}

// Initial call to filterItems to display all items
filterItems();
