<html>

<head>
    <style>
        body {
            background-color: rgb(247, 217, 246);
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #0a0e4f;
        }

        li {
            float: left;
        }

        li:last-child {
            border-right: none;
        }

        li a {
            font-size: 20px;
            display: block;
            color: rgb(244, 242, 242);
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover:not(.active) {
            background-color: #090909;
        }

        .active {
            background-color: #000000;
        }

        input {
            font-size: 20px;
            margin-top: 10px;
            margin-left: 200px;
            border: 1px black;
            border-style: solid;
            color: rgb(15, 0, 0);
        }

        #navtable {
            font-size: 40px;
            margin-top: -60px;
            margin-left: 1000px;
            color: rgb(15, 0, 0);
            background-color: #ff81ca;
        }


        #div2 {
            width: 1300;
            margin-left: 100px;
            margin-top: 20px;
            background-color: rgb(252, 252, 252);
        }

        #d1 {
            font-size: 100%;
            margin-top: 0px;
            margin-left: 5px;
            border: 3px rgb(0, 0, 0);
            border-radius: 10px;
            width: 80px;
            background-color: rgb(0, 0, 0);
        }

        a {
            color: #fff;
        }

        body,
        ul {
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1rem 0;
        }
        footer {
            text-align: center;
            margin-top: 20px;
        }
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    
    body {
        background-color: #f2f2f2;
        font-family: Arial, sans-serif;
        color: #333;
    }


    .cart {
        max-width: 600px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    }

    
    .cart h2 {
        font-size: 24px;
        margin-bottom: 20px;
    }

  
    .cart-item {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
        border-bottom: 1px solid #ddd;
        padding-bottom: 10px;
    }

    .cart-item img {
        border: 1px solid black;
        max-width: 150px;
        max-height: 200px;
        margin-right: 10px;
    }

    .cart-item p {
        margin: 0;
    }

  
    .removeItemBtn {
        width: 50%;
            margin-bottom: 10px;
            border: 1px solid black;
            display: inline-block;
            padding: 5px 10px;
            background-color:#e74c3c;
            color: #000000;
            text-decoration: none;
            border-radius: 5px;
        cursor: pointer;
    }
    .removeItemBtn:hover{
        background-color: #f61900;
    }

    .total-price {
        font-size: 18px;
        text-align: right;
        margin-top: 20px;
    }

 
    .cart-item p:first-child {
        flex: 1;
    }


    .cart-item img,
    .cart-item p,
    .cart-item button {
        align-self: center;
        margin-left: 70px;
        margin-top: 20px;
    }

    .link-box {
            width: 35%;
            margin-bottom: 10px;
            border: 1px solid rgba(6, 6, 6, 0.714);
            display: inline-block;
            padding: 10px 20px;
            background-color:green (239, 150, 7, 0.775);
            color: #000000;
            text-decoration: none;
            border-radius: 5px;
            margin-left: 65%;
            margin-top: 10px;
           
        }

        .link-box:hover {
            background-color:rgba(6, 173, 9, 0.714);
        }

        #t2 {
        
            background-color: rgba(14, 8, 8, 0.107);
            width: 1300px;
        }

        .footer
{
  background: #fff;
 
}

</style>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-compactible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
</head>

<body>
    <ul>
        <li><a class="active" href="products.html">Products</a></li>

        <input style="width: 500px; height:30px;" type="search"
            placeholder="   search for Vegitables,Fruits,Dairy,Meat, flowers                               🔎">

        <li style="float:right; margin-right: 100px;"><a href="contactus.html">Contact Us</a></li>
    </ul>

    <div id="div2">
        <h5 id="d1">
            <center><a href="index.php">⬅ Back</a></center>
        </h5>
        <header>
            <h1>Shopping Cart</h1>
        </header>
            <div class="cart">
                <h2>Your Cart</h2>
                <div id="cartItems">
                   
                </div>
                <p class="total-price">Total Price: $<span id="totalPrice">0.00</span></p>
                <a href="payment.php" class="link-box"><center>Buy Now</center></a><br></td>
            </div>
            
        <br><br><br>
        <script>
            function updateCartDisplay() {
                const cartItems = document.getElementById('cartItems');
                const totalDisplay = document.getElementById('totalPrice');
                cartItems.innerHTML = '';
    
                
                const cart = JSON.parse(localStorage.getItem('cart')) || [];
                let totalPrice = 0;
    
                for (let i = 0; i < cart.length; i++) {
                    const item = cart[i];
    
                    const itemContainer = document.createElement('div');
                    itemContainer.classList.add('cart-item');
                    const itemImage = document.createElement('img');
                    itemImage.src = item.image;
                    itemImage.alt = item.name;
                    itemContainer.appendChild(itemImage);
    
                    const itemDetails = document.createElement('div');
                    itemDetails.innerHTML = `
                        <p>${item.name}</p>
                        <p>Price: $${item.price.toFixed(2)}</p>
                        <button class="removeItemBtn" data-index="${i}">Remove</button>
                    `;
                    itemContainer.appendChild(itemDetails);
                    cartItems.appendChild(itemContainer);
    
                    totalPrice += item.price;
                }
    
                totalDisplay.textContent = totalPrice.toFixed(2);
    
               
                const removeItemButtons = document.querySelectorAll('.removeItemBtn');
                removeItemButtons.forEach(button => {
                    button.addEventListener('click', function () {
                        const indexToRemove = parseInt(button.getAttribute('data-index'));
    
                        
                        cart.splice(indexToRemove, 1);
    
                        
                        localStorage.setItem('cart', JSON.stringify(cart));
    
                        
                        updateCartDisplay();
                    });
                });
            }
    
           
            updateCartDisplay();
        </script>


        <!-- footer -->
<!-- <section class="footer">
	<div class="box-container">
		<div class="box">
			<h3> Groco <i class="fa fa-shopping-basket"></i></h3>
			<p> feel free to follow us on our social media handlers all the links are given below</p>
			<div class="share">
				<a href="https://www.facebook.com/abhishek.s.ishi/" class="fa fa-facebook"></a>
				<a href="https://twitter.com/IshiAbhish80239" class="fa fa-twitter"></a>
				<a href="https://www.instagram.com/abhishek_ishi/" class="fa fa-instagram"></a>
				<a href="https://www.linkedin.com/in/abhishek-ishi-0546a9215/" class="fa fa-linkedin"></a>
			</div>
		</div>
		<div class="box">
			<h3> Contact Info</h3>
			<a href="tel:+913922701896" class="links"> <i class="fa fa-phone"> +919322701896</i></a>
			<a href="tel:+919049056720" class="links"> <i class="fa fa-phone"> +919049056720</i></a>
			<a href="mailto:abhishekishi2002@gmail.com" class="links"> <i class="fa fa-envelope"> abhishekishi2002@gmail.com</i></a>
			<a href="https://www.google.co.in/maps/place/Pune,+Maharashtra/" class="links"> <i class="fa fa-map-marker"> Pune, Maharastra, India</i></a>
		</div>

		<div class="box">
			<h3> Quick Links</h3>
			<a href="#" class="links"> <i class="fa fa-arrow-right"> Home</i></a>
			<a href="features.html" class="links"> <i class="fa fa-arrow-right"> features</i></a>
			<a href="products.html" class="links"> <i class="fa fa-arrow-right"> Products</i></a>
			<a href="categories.html" class="links"> <i class="fa fa-arrow-right"> Categories</i></a>
			<a href="#" class="links"> <i class="fa fa-arrow-right"> Review</i></a>
			
		</div>

		<div class="box">
			<h3> Newsletter</h3>
			<p> Subscribe for Latest updates</p>
			<input type="email" placeholder="your email" class="email" >
			<input type="submit" value="Subscribe" class="btn">
			<img src="Image/payment.png" class="payment-img">
		</div>
	</div>

<div class="credit">Created By <span>Ishi Abhishek</span> all Rights Reserved </div>

</section> -->

<!-- Footer -->

        <div>
            <center>
                <table id="t2" border="0px" width="1300" height="300">
                    <tr>
                        <td>
                            <center>
                                <h3>Quick Links</h3>
                            </center>
                        </td>
                        <td>
                            <center>
                                <h3>Extra Links</h3>
                            </center>
                        </td>
                        <td>
                            <center>
                                <h3>Location</h3>
                            </center>
                        </td>
                        <td>
                            <center>
                                <h3>Contacts Info</h3>
                            </center>
                    </tr>
                    <tr>
                        <td>
                            <center><a href="index.php">Home</a></center>
                        </td>
                        <td>
                            <center>My Account</center>
                        </td>
                        <td>
                            <center>India</center>
                        </td>
                        <td>
                            <center>Mo no: +91 9322701896</center>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <center>About</center>
                        </td>
                        <td>
                            <center>My Order</center>
                        </td>
                        <td>
                            <center></center>
                        </td>
                        <td>
                            <center>abhishekishi2002@gmail.com</center>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <center><a href="product.html">Product</a></center>
                        </td>
                        <td>
                            <center>My Favorite</center>
                        </td>
                        <td>
                            <center></center>
                        </td>
                        <td>
                            <center>Pune,India-412207</center>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <center>Review</center>
                        </td>
                        <td>
                            <center></center>
                        </td>
                        <td>
                            <center></center>
                        </td>
                        <td>
                            <center></center>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <center>Contact</center>
                        </td>
                        <td>
                            <center></center>
                        </td>
                        <td>
                            <center></center>
                        </td>
                        <td>
                            <center></center>
                        </td>
                    </tr>
                </table>
        </div>
        <br><br>

    </div>
    
</body>

</html>