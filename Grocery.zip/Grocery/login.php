


<?php 
include 'config.php';
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login page</title>
</head>
<link rel="stylesheet" href="bootstrap.min.css" />
<style>
    body{
        background-image: url('a.jpg');
        background-size:cover;
    }
    .col-xl-5{
        background:rgba(0,0,0,0.5);
        border-radius:15px 0px;
    }
    p{
        background:rgba(255, 255, 255, 0.845);
    }
    .row{
margin-top:150px;
    }
</style>

    <body>
        
            <div class="container">
                <div class="row">
                    <div class="col-xl-5 col-md-4 m-auto p-4 ">
                        <h3 class="heading text-center">Login Now</h3>
                        <!-- Form Start -->
                        <form  action="" method ="POST">
                            
                                <input type="text" name="email" class="form-control mb-3" placeholder="Enter Your Email" required>
                                <input type="password" name="password" class="form-control mb-3 " placeholder="Enter Your Password" required>
                                <input type="submit" name="submit" class="btn btn-primary mb-3" value="Login" />
                                <a href="Registration.php" class="btn btn-primary mb-3"><label>New Registration <label></a><br>
                                 
                                <div>

                                    <?php
                                     
                                     if(isset($_SESSION['error'])){
                                        $error=$_SESSION['error'];
                                        echo "<p class='text-danger font-weight-bold text-center p-1'>".$error."</p>";
                                        unset($_SESSION['error']);
                                     }
                                    ?>
                                </div>
                        </form>
                        
                        <a href="forgot_pass.php" class="text-white"><label>Fotgot password <label></a>
                        
                        <!-- /Form  End -->
                    </div>
                </div>
            </div>
        
    </body>

</html>

<?php
if(isset($_POST['submit'])){
    $email=$_POST['email'];
    $password=$_POST['password'];
   
    $sql="SELECT * FROM `login2` WHERE `email`='{$email}' AND `password`='{$password}'";
    $query=mysqli_query($con,$sql);
    $data=mysqli_num_rows($query);
    if($data){
      header("location:index.php");
    }

    else{
        $_SESSION['error']="Invalid email/password";
        header("location:login.php");
    }



}



?>