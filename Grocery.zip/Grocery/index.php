
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Grocery Store By Cyber Warriors</title>

<!-- Code for font awesome cdn -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Code for font awesome cdn -->

<!-- Code for Link Css -->
<link rel="stylesheet" type="text/css" href="css/style.css">
<!-- Code for link css -->

<!-- Code for sliddrr -->
<link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
<!-- Code for sliddrr -->
</head>
<body>

<!-- Code for header section -->
<header class="header">
		<a href="#" class="logo"> <i class="fa fa-shopping-basket" aria-hidden="true"></i> Grocery </a>


<nav class="navbar">
	
	<a href="index.php">home</a>

	<?php
	include "config.php";
	$sql="SELECT * FROM `category`";
	$query=mysqli_query($con,$sql);
	
	if($query){
		while($result=mysqli_fetch_assoc($query)){
      ?>
	  <a href="product.php?id=<?= $result['category_id'] ?>"><?= $result['category_name'] ?></a>
	  <?php
		}
	}
	?>

	
	
	
</nav>

<div class="icons">
	
	<div class="fa fa-search" id="search-btn"></div>
	<div class="fa fa-shopping-cart" id="cart-btn"></div>
	<div class="fa fa-user" id="login-btn"></div>
		
</div>

<form class="search-form">

	<input type="search" id="search-box" placeholder="search here....">
	<label for="search-box=" class="fa fa-search"></label>

</form>

<div class="shopping-cart">
	<!-- <div class="box">
		<i class="fa fa-trash"></i>
		<img src="image/1.png">
		<div class="content">
			<h3>watermelon</h3>
			<span class="price">Rs.50/-</span>
			<span class="quntity">Qty : 1/-</span>
		</div>
	</div>

	<div class="box">
		<i class="fa fa-trash"></i>
		<img src="image/2.png">
		<div class="content">
			<h3>Banana</h3>
			<span class="price">Rs.40/-</span>
			<span class="quntity">Qty : 1/-</span>
		</div>
	</div>

	<div class="box">
		<i class="fa fa-trash"></i>
		<img src="image/3.png">
		<div class="content">
			<h3>Orange</h3>
			<span class="price">Rs.100/-</span>
			<span class="quntity">Qty : 1/-</span>
		</div>
	</div> -->

<!-- <div class="total">total : Rs 190/-</div> -->
<a href="cart.php" class="btn">Go To Cart</a>

</div>

<form action="" method="post" class="login-form">
	<h3>Login</h3>
	<input type="email" name="email" placeholder="your email" class="box" required>
	<input type="Password" name="password" placeholder="your password" class="box" required>

<p>Forget your password <a href="#">Click Here</a>
<p>New User <a href="Registration.php">click Here</a>	
	
	<input type="submit" name="submit" value="Login now" class="btn">
</form>
	 
</header>

<!-- banner section -->
<section class="home" id="home">
	<div class="content">
		<h3>Fresh And <span>Organic</span> Food For You</h3>
		<p>This website is designed by Abhishek so that everyone used easily </p>
		<a href="All_products.php" class="btn">shop now</a>
	</div>
</section>

<!-- banner section -->


<!-- our review section -->
<section class="review" id="review">

	<h1 class="heading"> Customer's <span>review</span> </h1>


	<div class="box-container">

	<?php $sql1="SELECT * FROM `feedback`";
	$query1=mysqli_query($con,$sql1);
	
	if($query1){
		while($result1=mysqli_fetch_assoc($query1)){
     ?>
	 <div class="box">
			<img src="Image/rohit.jpeg">
			
			<p><?= $result1['description'] ?></p>
			<h3><?= $result1['name'] ?></h3>
			<h5><?= $result1['postingDate'] ?></h5>
		</div>
	 <?php
		
		}}
	 ?>
		


	
	</div>
</section>


<a href="feed.php" class="btn">Submit Your Review</a>
   

<!-- our review section -->

<!-- footer -->
<section class="footer">
	<div class="box-container">
		<div class="box">
			<h3> Groco <i class="fa fa-shopping-basket"></i></h3>
			<p> feel free to follow us on our social media handlers all the links are given below</p>
			<div class="share">
				<a href="https://www.facebook.com/abhishek.s.ishi/" class="fa fa-facebook"></a>
				<a href="https://twitter.com/IshiAbhish80239" class="fa fa-twitter"></a>
				<a href="https://www.instagram.com/abhishek_ishi/" class="fa fa-instagram"></a>
				<a href="https://www.linkedin.com/in/abhishek-ishi-0546a9215/" class="fa fa-linkedin"></a>
			</div>
		</div>
		<div class="box">
			<h3> Contact Info</h3>
			<a href="tel:+913922701896" class="links"> <i class="fa fa-phone"> +919322701896</i></a>
			<a href="tel:+919049056720" class="links"> <i class="fa fa-phone"> +919049056720</i></a>
			<a href="mailto:abhishekishi2002@gmail.com" class="links"> <i class="fa fa-envelope"> abhishekishi2002@gmail.com</i></a>
			<a href="https://www.google.co.in/maps/place/Pune,+Maharashtra/" class="links"> <i class="fa fa-map-marker"> Pune, Maharastra, India</i></a>
		</div>

		<div class="box">
			<h3> Quick Links</h3>
			<a href="#" class="links"> <i class="fa fa-arrow-right"> Home</i></a>
			<a href="features.html" class="links"> <i class="fa fa-arrow-right"> features</i></a>
			<a href="product.php" class="links"> <i class="fa fa-arrow-right"> Products</i></a>
			<a href="categories.html" class="links"> <i class="fa fa-arrow-right"> Categories</i></a>
			<a href="#" class="links"> <i class="fa fa-arrow-right"> Review</i></a>
			
		</div>

		<div class="box">
			<h3> Newsletter</h3>
			<p> Subscribe for Latest updates</p>
			<input type="email" placeholder="your email" class="email" >
			<input type="submit" value="Subscribe" class="btn">
			<img src="Image/payment.png" class="payment-img">
		</div>
	</div>

<div class="credit">Created By <span>Ishi Abhishek</span> all Rights Reserved </div>

</section>

<!-- footer -->


<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>

<script src="js/script.js"></script>

</body>
</html>



